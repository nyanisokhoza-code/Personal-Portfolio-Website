# Project Submission — Nyaniso Khoza

**Personal Portfolio Website**
Submission date: 02 September 2026

---

## 1. Live deployed portfolio website

**https://nyanisokhoza-code.github.io/Personal-Portfolio-Website/**

Hosted on GitHub Pages, deployed directly from the `main` branch of the repository below.

## 2. Project source code / repository

**https://github.com/nyanisokhoza-code/Personal-Portfolio-Website**

A copy of the source code as of this submission is also included here in `Source-Code/`,
in case offline access is needed. The GitHub repository is the authoritative, up-to-date
version — always check there first.

## 3. PowerPoint presentation

`Presentation/Nyaniso-Khoza-Portfolio-Presentation.pptx`

A 17-slide walkthrough covering: Introduction, Purpose, Design Concept, Technologies Used,
Home Page, About Me, Skills, Projects, Education & Certifications, Work Experience, Contact,
CV Functionality, Responsive Design, Source Code, Live Deployment, and Conclusion.

---

## What's in this folder

```
Project-Submission/
│
├── README.md                                    ← this file
│
├── CV/
│   └── Nyaniso-Khoza-CV.pdf                      ← current CV (also downloadable from the live site)
│
├── Presentation/
│   └── Nyaniso-Khoza-Portfolio-Presentation.pptx
│
└── Source-Code/                                  ← copy of the website source
    ├── index.html
    ├── README.md
    ├── CHANGELOG.md
    ├── CONTENT-TO-ADD.md
    ├── css/style.css
    ├── js/script.js
    ├── assets/
    │   ├── documents/Nyaniso-Khoza-CV.pdf
    │   ├── images/
    │   └── icons/
    └── projects/
```

## Status of site content

Filled in with real information: About, Skills, Work Experience (SBK Projects and
Assignments — three roles), Education (Support Systems Diploma, IT: Database
Administration, National Senior Certificate), Certifications (six, all verified from
source certificates), and Contact (Email, Phone, GitHub, LinkedIn — all live links).

Still placeholder, pending confirmation:
- **Projects** — three project card slots are built and styled, awaiting real project
  content, screenshots and links.

See `Source-Code/CONTENT-TO-ADD.md` for the full outstanding checklist.
