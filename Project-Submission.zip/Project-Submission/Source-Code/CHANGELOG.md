# Changelog

## V1.1.1 — CV Button Fix
- CV button now checks whether the PDF exists before linking to it.
- If the PDF isn't there yet, it shows a "CV coming soon" tooltip instead of a broken-file error.
- Once `Nyaniso-Khoza-CV.pdf` is added to `assets/documents/`, the button re-enables automatically — no code change needed.

## V1.1.0 — Floating CV Control
- Added floating "Download CV" tab, fixed to the right edge of the viewport, visible across the site.
- Repositioned CV control to a bottom-right pill on mobile/tablet.
- Renamed `downloads/` to `assets/documents/`; CV button points to `assets/documents/Nyaniso-Khoza-CV.pdf`.
- Updated README and content checklist to match.

## V1.0.0 — Initial Portfolio Build
- Created Executive Dark / Glass visual direction.
- Added responsive navigation.
- Added hero/profile section using NK initials.
- Added About section.
- Added skills section.
- Added work experience timeline.
- Added three project placeholders.
- Added education section.
- Added certification placeholder.
- Added contact section.
- Added responsive mobile layout.
- Added scroll/reveal animations.
